package GameInfo;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.util.ArrayList;

public class Level{ 
    private ArrayList<Block> blocks = new ArrayList<Block>();
    private ArrayList<MovableBlock> movableBlocks = new ArrayList<MovableBlock>();
    private ArrayList<KillBlock> killBlocks = new ArrayList<KillBlock>();
    private ArrayList<EndBlock> endBlocks = new ArrayList<EndBlock>();
    private Player player;
    private int playerX;
    private int playerY;
    //private Level1 level1;
    public Level(int levelNum, int playerX, int playerY, Player p){
        //could probably store all this in a JSON but i aint learnin allat
        if(levelNum == 1){
            blocks.add(new Block(0, 400, 768, 174, new Color(82,3,3)));
            blocks.add(new Block(0, 0, 100, 576, new Color(82,3,3)));
            blocks.add(new Block(668, 0, 100, 576, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(200, 350, 100, 50, Color.GREEN, true, false));
            endBlocks.add(new EndBlock(667,300,100,100));
            killBlocks.add(new KillBlock(0,0,768,100));
        }
        if(levelNum == 2){
            blocks.add(new Block(0,400,468,174, new Color(82,3,3)));
            blocks.add(new Block(0,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(668,0,100,576, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(468,150,200,100,Color.GREEN, true, false));
            endBlocks.add(new EndBlock(667,101,100,100));
            killBlocks.add(new KillBlock(0,0,768,100));
        }
        if(levelNum == 3){
            killBlocks.add(new KillBlock(0,0,768,100));
            blocks.add(new Block(0,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(668,0,100,576, new Color(82,3,3)));
            endBlocks.add(new EndBlock(667,300,100,100));
            movableBlocks.add(new MovableBlock(100,400,300,174,Color.YELLOW,false,true));
        }
        if(levelNum == 4){
            blocks.add(new Block(0,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(668,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(0, 400, 768, 174, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(200, 400, 250, 50, Color.GREEN, true, false));
            killBlocks.add(new KillBlock(400, 350, 50, 50));
            killBlocks.add(new KillBlock(0,0,768,100));
            endBlocks.add(new EndBlock(667,300,100,100));
        }
        if(levelNum == 5){
            blocks.add(new Block(0, 400, 768, 174, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(100,400,568,75, Color.GREEN, true, false));
            endBlocks.add(new EndBlock(300,0,101,51));
            killBlocks.add(new KillBlock(0,0,768,50));
            killBlocks.add(new KillBlock(0,0,100,100));
            killBlocks.add(new KillBlock(0,200,100,376));
            killBlocks.add(new KillBlock(668,0,100,200));
            killBlocks.add(new KillBlock(668,300,100,276));
            blocks.add(new Block(667,200,101,100, new Color(82,3,3)));
            blocks.add(new Block(0,100,100,100, new Color(82,3,3)));
        }
        if(levelNum == 6){
            movableBlocks.add(new MovableBlock(0,400,668,75, Color.GREEN, true, false));
            killBlocks.add(new KillBlock(668,0,100,576));
            killBlocks.add(new KillBlock(300, 0, 20, 250));
            killBlocks.add(new KillBlock(300, 350, 20, 226));
            killBlocks.add(new KillBlock(400, 0, 20, 200));
            killBlocks.add(new KillBlock(400, 300, 20, 276 ));
            killBlocks.add(new KillBlock(500, 0, 20, 250));
            killBlocks.add(new KillBlock(500, 350, 20, 226));
            endBlocks.add(new EndBlock(667, 200, 100, 100));
        }
        if(levelNum == 7){
            movableBlocks.add(new MovableBlock(0,400,85,126,Color.YELLOW,false,true));
            killBlocks.add(new KillBlock(668,0,100,576));
            endBlocks.add(new EndBlock(667, 235, 100, 100));
        }
        if(levelNum == 8){
            blocks.add(new Block(200,526,368,50,new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(200, 100, 50, 100, Color.GREEN, true, false));
            movableBlocks.add(new MovableBlock(508, 250, 50, 100, Color.GREEN, true, false));
            killBlocks.add(new KillBlock(0,0,200,576));
            killBlocks.add(new KillBlock(558,0,200,576));
            endBlocks.add(new EndBlock(101, 426, 100,100));
        }
        if(levelNum == 9){ 
            movableBlocks.add(new MovableBlock(100,496,568,80,Color.GREEN,true,false));
            blocks.add(new Block(668,100,100,200, new Color(82,3,3)));
            killBlocks.add(new KillBlock(0, 0, 100, 576));
            killBlocks.add(new KillBlock(0, 668, 100, 99));
            killBlocks.add(new KillBlock(668, 301, 100, 575));
            killBlocks.add(new KillBlock(0,0,768,50));
            killBlocks.add(new KillBlock(100,300,350,20));
            killBlocks.add(new KillBlock(600,300,68,20));
            killBlocks.add(new KillBlock(400,300,20,80));
            killBlocks.add(new KillBlock(400,476,20,100));
            killBlocks.add(new KillBlock(100, 100, 68, 20));
            killBlocks.add(new KillBlock(318, 100, 350, 20));
            killBlocks.add(new KillBlock(340, 100, 20, 60));
            killBlocks.add(new KillBlock(340, 220, 20, 80));
            endBlocks.add(new EndBlock(100, 0, 250, 51));
        }
        if(levelNum == 10){ 
            movableBlocks.add(new MovableBlock(100,180,568,80,Color.GREEN,true,false));
            blocks.add(new Block(0,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(668,0,100,576, new Color(82,3,3)));
            killBlocks.add(new KillBlock(0,0,768,50));
            killBlocks.add(new KillBlock(100,200,350,20));
            killBlocks.add(new KillBlock(600,200,68,20));
            killBlocks.add(new KillBlock(100, 400, 68, 20));
            killBlocks.add(new KillBlock(318, 400, 350, 20));
            endBlocks.add(new EndBlock(0,476,100,100));
        }

        this.playerX = playerX;
        this.playerY = playerY;
        p.setX(playerX);
        p.setY(playerY);
        player = p;
    }
    public ArrayList<Block> getBlocks(){return blocks;}
    public ArrayList<MovableBlock> getMovableBlocks(){return movableBlocks;}
    public ArrayList<EndBlock> getEndBlocks(){return endBlocks;}
    public ArrayList<KillBlock> getKillBlocks(){return killBlocks;}
    public void paintBlockComponent(Graphics g, Block i, Color h){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(h);
        g2d.fillRect(i.getX(),i.getY(),i.getLength(),i.getWidth());
    }
    public Player getPlayer(){
        return player;
    }
    public int getPlayerX(){return playerX;}
    public int getPlayerY(){return playerY;}
    public void paintMovableBlockComponent(Graphics g, MovableBlock i, Color h){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(h);
        g2d.fillRect(i.getX(),i.getY(),i.getLength(),i.getWidth());
    }
    public void paintEndBlockComponent(Graphics g, EndBlock j){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(new Color(71,179,55));
        g2d.fillRect(j.getX(),j.getY(),j.getLength(),j.getWidth());
    }
    public void paintKillBlockComponent(Graphics g, KillBlock j){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(j.getColor());
        g2d.fillRect(j.getX(),j.getY(),j.getLength(),j.getWidth());
    }
}
