package GameInfo;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class HelpMenu extends JPanel {
    private MainGameWindow player;
    private JLabel helpLabel = new JLabel("Help");
    private JLabel redLabel = new JLabel("RED");
    private JLabel redDescLabel = new JLabel(" - Kills when touched");
    private JLabel deepRedLabel = new JLabel("DEEP RED");
    private JLabel deepRedDescLabel = new JLabel(" - Normal block");
    private JLabel greenLabel = new JLabel("GREEN");
    private JLabel greenDescLabel = new JLabel(" - Can be moved vertically");
    private JLabel yellowLabel = new JLabel("YELLOW");
    private JLabel yellowDescLabel = new JLabel(" - Can be moved horizontally");
    private JLabel tealLabel = new JLabel("BLUE");
    private JLabel tealDescLabel = new JLabel(" - Moves automatically");
    private JLabel greenishLabel = new JLabel("GREEN (Better)");
    private JLabel greenishDescLabel = new JLabel(" - Sends to next level");
    private JButton toMenu = new JButton("Back");
    private JFrameLayout jFrameLayout;

    public HelpMenu(MainGameWindow player, JFrameLayout jFrameLayout) {
        setLayout(null); 
        setBackground(Color.BLACK);
        this.player = player;
        this.jFrameLayout = jFrameLayout;
        initPanel(); 
        setVisible(true);
    }

    public void initPanel() {
        helpLabel.setFont(new Font("SERIF", Font.BOLD, 30));
        helpLabel.setBounds(334,10,200,50);
        helpLabel.setForeground(Color.WHITE);
        //red Description
        redDescLabel.setFont(new Font("ARIAL", Font.BOLD, 30));
        redDescLabel.setBounds(160,100,1000,50);
        redDescLabel.setForeground(Color.WHITE);
        redLabel.setFont(new Font("SERIF", Font.BOLD, 30));
        redLabel.setBounds(100,100,100,50 );
        redLabel.setForeground(Color.RED);
        //deep red Description
        deepRedDescLabel.setFont(new Font("ARIAL", Font.BOLD, 30));
        deepRedDescLabel.setBounds(250,160,1000,50);
        deepRedDescLabel.setForeground(Color.WHITE);
        deepRedLabel.setFont(new Font("SERIF", Font.BOLD, 30));
        deepRedLabel.setBounds(100,160,300,50);
        deepRedLabel.setForeground(new Color(82,3,3));
        //green Description
        greenDescLabel.setFont(new Font("ARIAL", Font.BOLD, 30));
        greenDescLabel.setBounds(205,220,1000,50);
        greenDescLabel.setForeground(Color.WHITE);
        greenLabel.setFont(new Font("SERIF", Font.BOLD, 30));
        greenLabel.setBounds(100,220,300,50);
        greenLabel.setForeground(Color.GREEN);
        //yellow description
        yellowDescLabel.setFont(new Font("ARIAL", Font.BOLD, 30));
        yellowDescLabel.setBounds(230,280,1000,50);
        yellowDescLabel.setForeground(Color.WHITE);
        yellowLabel.setFont(new Font("SERIF", Font.BOLD, 30));
        yellowLabel.setBounds(100,280,300,50);
        yellowLabel.setForeground(Color.YELLOW);
        //blue description
        tealDescLabel.setFont(new Font("ARIAL", Font.BOLD, 30));
        tealDescLabel.setBounds(180,340,1000,50);
        tealDescLabel.setForeground(Color.WHITE);
        tealLabel.setFont(new Font("SERIF", Font.BOLD, 30));
        tealLabel.setBounds(100,340,300,50);
        tealLabel.setForeground(new Color(0,240,251));
        //greenish description
        greenishDescLabel.setFont(new Font("ARIAL", Font.BOLD, 30));
        greenishDescLabel.setBounds(310,400,1000,50);
        greenishDescLabel.setForeground(Color.WHITE);
        greenishLabel.setFont(new Font("SERIF", Font.BOLD, 30));
        greenishLabel.setBounds(100,400,300,50);
        greenishLabel.setForeground(new Color(71,179,55));
        // buttons
        toMenu.setFont(new Font("Arial", Font.BOLD, 15));
        toMenu.setBounds(214,25,100,25);

       
        toMenu.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                player.toMenu();
            }
        });

        add(toMenu);
        add(helpLabel);
        add(redLabel);
        add(deepRedLabel);
        add(greenLabel);
        add(yellowLabel);
        add(tealLabel);
        add(greenishLabel);
        add(redDescLabel);
        add(deepRedDescLabel);
        add(greenDescLabel);
        add(yellowDescLabel);
        add(tealDescLabel);
        add(greenishDescLabel);
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(30,60,15,430);
        g2d.fillRect(30,60,688,15);
        g2d.fillRect(703,60,15,430);
        g2d.fillRect(30,475,688,15);
    }

}
