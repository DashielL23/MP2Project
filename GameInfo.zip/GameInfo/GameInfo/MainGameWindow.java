package GameInfo;

import javax.swing.JPanel;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;

import java.util.ArrayList;

//ok so the Main window extends JPanel, part of JFRAME, so i don't need to do whole shenanigans when defining, and the implements Runnable means I can use threads to execute stuff via threads instead of something like a timer
public class MainGameWindow extends JPanel implements Runnable{

    //All the objects!
    private Thread gameThread;
    private MouseActions mouseAction;

    private final int originalTileSize = 16;
    private final int scale = 3;
    private final int tileSize = originalTileSize * scale; // 48x48 pixels
    private final int maxScreenWidth = 16;
    private final int maxScreenHeight = 12;
    private final int screenWidth = maxScreenWidth * tileSize; // 768 px
    private final int screenHeight = maxScreenHeight * tileSize; //  576 px
    private JFrameLayout panels;
    private Level currentLevel;
    private ArrayList<Level> levels = new ArrayList<>();
    private MenuScreen menuScreen;
    private int levelCounter = 0;
    private boolean isDead = false;
    private boolean inMenu = false;
    private SoundPlayer metalPipe = new SoundPlayer("MetalPipeSFX.wav");
    private SoundPlayer overdose /*NAME OF THE SONG DONT FLAME ME */ = new SoundPlayer("Overdose.wav");
    private SoundPlayer jumpscare = new SoundPlayer("Jumpscare.wav");
    //Constructor for game window
    public MainGameWindow(MouseActions mouseAction, JFrameLayout jFrameLayout, MenuScreen a){
        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.BLACK);
        this.setDoubleBuffered(true);
        this.addMouseListener(mouseAction);
        this.addMouseMotionListener(mouseAction);
        this.mouseAction = mouseAction;
        this.panels = jFrameLayout;
        menuScreen = a;
    }
    //initializes thread
    public void startGame(){
        gameThread = new Thread(this);
        gameThread.start();
    }
    
    //add levels
    public void addLevels(){
        levels.add(new Level(1, 100, 400, new Player()));
        levels.add(new Level(2, 110, 350, new Player()));
        levels.add(new Level(3, 110, 350, new Player()));
        levels.add(new Level(4,110,400, new Player()));
        levels.add(new Level(5,110,400,new Player()));
        levels.add(new Level(6,0,350, new Player()));
        levels.add(new Level(7,110,0, new Player()));
        levels.add(new Level(8,201,0, new Player()));
        levels.add(new Level(9,110,445, new Player()));
        levels.add(new Level(10,110,101, new Player()));
        currentLevel = levels.get(0);
    
    }
    //game loop
    @Override
    public void run(){
        overdose.startAudio();
        overdose.setLoop();
        //runs while object exists
        while(!inMenu){
            updateGameStuff();
            //repaint (update screen)
            repaint();

            //delay for game loop
            
            try{
                Thread.sleep(16); //60 FPS me thinks
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }

    public void paintComponent(Graphics g){ // graphics class which deals with painting stuff onto things like a JFRAME.
        super.paintComponent(g); //prevents background from being F'd up
        Graphics2D g2d = (Graphics2D)g; // Take the normal graphics, cast it into a 2d Graphics which I can do more specific stuff with
        for(Block i: currentLevel.getBlocks()){currentLevel.paintBlockComponent(g2d, i, i.getColor());}
        for(MovableBlock j: currentLevel.getMovableBlocks()){currentLevel.paintMovableBlockComponent(g2d, j, j.getColor());}
        for(KillBlock l: currentLevel.getKillBlocks()){currentLevel.paintKillBlockComponent(g2d,l);}
        for(EndBlock k: currentLevel.getEndBlocks()){currentLevel.paintEndBlockComponent(g2d, k);}
        this.currentLevel.getPlayer().paintComponent(g2d);
        g2d.dispose();
    }

    public void updateGameStuff(){
        currentLevel.getPlayer().xIncrement();
        currentLevel.getPlayer().yIncrement();
        updatePlayerCollision();
        updateMovableBlock();
        updateEndBlockCollision();
        updateKillBlockCollision();
        detectDeath();
    }

    public void updatePlayerCollision(){
        for(Block i : currentLevel.getBlocks()){
            if(currentLevel.getPlayer().getPlayerVerticalBounds().intersects(i.getBounds())){
                if(currentLevel.getPlayer().getYVel() <= 3){
                    currentLevel.getPlayer().setYVel(0);
                    currentLevel.getPlayer().noGravity();
                }
                else{
                    currentLevel.getPlayer().setYVel(-(int)(currentLevel.getPlayer().getYVel() * .5));
                    currentLevel.getPlayer().setY(i.getY()-51);
                    currentLevel.getPlayer().resetPlayerGravity();
                }
            }
            if(currentLevel.getPlayer().getPlayerHorizontalBounds().intersects(i.getBounds())){
                currentLevel.getPlayer().setXVel(-currentLevel.getPlayer().getXVel());
            }
        }
    }
    public void updateMovableBlock(){
        for(MovableBlock i: currentLevel.getMovableBlocks()){
            if(mouseAction.getMouseBounds().intersects(i.getBounds()) && mouseAction.getDragging() && i.getVMovable()) i.moveBlockY(mouseAction.getMouseY()-(i.getWidth()/2));
            if(mouseAction.getMouseBounds().intersects(i.getBounds()) && mouseAction.getDragging() && i.getHMovable() && !currentLevel.getPlayer().getPlayerHorizontalBounds().intersects(i.getBounds())) i.moveBlockX(mouseAction.getMouseX()- (i.getLength()/2));
            if(currentLevel.getPlayer().getPlayerVerticalBounds().intersects(i.getBounds())){
                if(currentLevel.getPlayer().getYVel() <= 3 && !currentLevel.getPlayer().getPlayerHeadForMovableBlocks().intersects(i.getBounds())){
                    currentLevel.getPlayer().setY(i.getY()-50);
                    currentLevel.getPlayer().noGravity();
                    currentLevel.getPlayer().setYVel(0);
                }
                else if(!currentLevel.getPlayer().getPlayerHeadForMovableBlocks().intersects(i.getBounds())){
                    currentLevel.getPlayer().setYVel(-(int)(currentLevel.getPlayer().getYVel() * .5));
                    currentLevel.getPlayer().setY(i.getY()-51);
                    currentLevel.getPlayer().resetPlayerGravity();
                }
                if(currentLevel.getPlayer().getPlayerHeadForMovableBlocks().intersects(i.getBounds())){
                    i.moveBlockY((int)currentLevel.getPlayer().getY()-i.getWidth()-1);
                }


            }
            if(currentLevel.getPlayer().getPlayerHorizontalBounds().intersects(i.getBounds())){
                currentLevel.getPlayer().setXVel(-currentLevel.getPlayer().getXVel());
            }
        }
    }

    public void updateKillBlockCollision(){
        for(KillBlock i: currentLevel.getKillBlocks()){
            if(currentLevel.getPlayer().getPlayerHorizontalBounds().intersects(i.getBounds())){
                isDead = true;
            }
        }
    }
    public void updateEndBlockCollision(){
        for(EndBlock i: currentLevel.getEndBlocks()){
            if(currentLevel.getPlayer().getPlayerHorizontalBounds().intersects(i.getBounds())){
                levelCounter++;
                try{
                    currentLevel = levels.get(levelCounter);
                }
                catch(java.lang.IndexOutOfBoundsException e){
                    overdose.stopAudio();
                    jumpscare.startAudio();
                    panels.getCardLayout().show(panels.getCardPanel(),"End");
                }
            }
        }
    }
    public void detectDeath(){
        if(currentLevel.getPlayer().getY() > 576){isDead = true;}
        if(isDead){
            metalPipe.startAudio();
            panels.getCardLayout().show(panels.getCardPanel(), "Game_Over");
            currentLevel.getPlayer().setXVel(0);
            currentLevel.getPlayer().setY(1000);
        }
        if(!isDead){
            metalPipe.resetAudio();
        }
    }
    public void resetLevel(){
        currentLevel.getPlayer().setX(currentLevel.getPlayerX());
        currentLevel.getPlayer().setY(currentLevel.getPlayerY()); 
        currentLevel.getPlayer().setYVel(5);
        currentLevel.getPlayer().resetPlayerGravity();
        currentLevel = levels.get(levelCounter);
        levels.set(levelCounter, new Level(levelCounter+1, currentLevel.getPlayer().getX(), (int)currentLevel.getPlayer().getY(), currentLevel.getPlayer()));
        isDead = false;
        currentLevel.getPlayer().setXVel(5);
        panels.getCardLayout().show(panels.getCardPanel(), "Game");
    }

    public void toMenu(){
        inMenu = true;
        overdose.stopAudio();
        menuScreen.restartMenuAudio();
        panels.getCardLayout().show(panels.getCardPanel(),"Menu");
    }
    public void setInMenu(boolean a){
        inMenu = a;
    }

}

