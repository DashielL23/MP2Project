package GameInfo;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.util.ArrayList;

public class Level{ 
    private ArrayList<Block> blocks = new ArrayList<Block>();
    private ArrayList<MovableBlock> movableBlocks = new ArrayList<MovableBlock>();
    private ArrayList<KillBlock> killBlocks = new ArrayList<KillBlock>();
    private ArrayList<EndBlock> endBlocks = new ArrayList<EndBlock>();
    private Player player;
    private int playerX;
    private int playerY;
    //private Level1 level1;
    public Level(int levelNum, int playerX, int playerY, Player p){
        if(levelNum ==1){
            blocks.add(new Block(0, 400, 768, 174, new Color(82,3,3)));
            blocks.add(new Block(0, 0, 100, 576, new Color(82,3,3)));
            blocks.add(new Block(668, 0, 100, 576, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(200, 300, 100, 200, Color.GREEN, true, false));
            endBlocks.add(new EndBlock(667,300,100,100));
            killBlocks.add(new KillBlock(0,0,768,100));
        }
        if(levelNum == 2){
            blocks.add(new Block(0,400,468,174, new Color(82,3,3)));
            blocks.add(new Block(0,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(668,0,100,576, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(468,150,200,100,Color.GREEN, true, false));
            endBlocks.add(new EndBlock(667,101,100,100));
            killBlocks.add(new KillBlock(0,0,768,100));
        }
        if(levelNum == 3){
            killBlocks.add(new KillBlock(0,0,768,100));
            blocks.add(new Block(0,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(668,0,100,576, new Color(82,3,3)));
            endBlocks.add(new EndBlock(667,300,100,100));
            movableBlocks.add(new MovableBlock(100,400,300,174,Color.YELLOW,false,true));
        }
        if(levelNum == 4){
            blocks.add(new Block(0,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(668,0,100,576, new Color(82,3,3)));
            blocks.add(new Block(0, 400, 768, 174, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(200, 400, 250, 50, Color.GREEN, true, false));
            killBlocks.add(new KillBlock(400, 350, 50, 50));
            killBlocks.add(new KillBlock(0,0,768,100));
            endBlocks.add(new EndBlock(667,300,100,100));
        }
        if(levelNum == 5){
            blocks.add(new Block(0, 400, 768, 174, new Color(82,3,3)));
            movableBlocks.add(new MovableBlock(100,400,568,75, Color.GREEN, true, false));
            endBlocks.add(new EndBlock(300,0,101,51));
            killBlocks.add(new KillBlock(0,0,768,50));
            killBlocks.add(new KillBlock(0,0,100,100));
            killBlocks.add(new KillBlock(0,200,100,376));
            killBlocks.add(new KillBlock(668,0,100,200));
            killBlocks.add(new KillBlock(668,300,100,276));
            blocks.add(new Block(667,200,101,100, new Color(82,3,3)));
            blocks.add(new Block(0,100,100,100, new Color(82,3,3)));
        }
        if(levelNum == 6){
            movableBlocks.add(new MovableBlock(0,400,668,75, Color.GREEN, true, false));
            killBlocks.add(new KillBlock(668,0,100,576));
            killBlocks.add(new KillBlock(300, 0, 20, 250));
            killBlocks.add(new KillBlock(300, 350, 20, 226));
            killBlocks.add(new KillBlock(400, 0, 20, 150));
            endBlocks.add(new EndBlock(667, 200, 100, 100));
        }

        this.playerX = playerX;
        this.playerY = playerY;
        p.setX(playerX);
        p.setY(playerY);
        player = p;
    }
    public ArrayList<Block> getBlocks(){return blocks;}
    public ArrayList<MovableBlock> getMovableBlocks(){return movableBlocks;}
    public ArrayList<EndBlock> getEndBlocks(){return endBlocks;}
    public ArrayList<KillBlock> getKillBlocks(){return killBlocks;}
    public void paintBlockComponent(Graphics g, Block i, Color h){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(h);
        g2d.fillRect(i.getX(),i.getY(),i.getLength(),i.getWidth());
    }
    public Player getPlayer(){
        return player;
    }
    public int getPlayerX(){return playerX;}
    public int getPlayerY(){return playerY;}
    public void paintMovableBlockComponent(Graphics g, MovableBlock i, Color h){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(h);
        g2d.fillRect(i.getX(),i.getY(),i.getLength(),i.getWidth());
    }
    public void paintEndBlockComponent(Graphics g, EndBlock j){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(new Color(71,179,55));
        g2d.fillRect(j.getX(),j.getY(),j.getLength(),j.getWidth());
    }
    public void paintKillBlockComponent(Graphics g, KillBlock j){
        Graphics g2d = (Graphics2D)g;
        g2d.setColor(j.getColor());
        g2d.fillRect(j.getX(),j.getY(),j.getLength(),j.getWidth());
    }
}
