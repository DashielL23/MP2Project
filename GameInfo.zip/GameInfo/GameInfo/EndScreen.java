package GameInfo;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import java.awt.Color;
public class EndScreen extends JPanel {
    private MainGameWindow player;
    private JFrameLayout jFrameLayout;
    private Image image;
    public EndScreen(MainGameWindow player, JFrameLayout jFrameLayout){
        setBackground(Color.BLACK);
        setLayout(null); 
        setVisible(true);
        this.player = player;
        this.jFrameLayout = jFrameLayout;
        initPanel(); 
    }

    public void initPanel(){
        try{image = ImageIO.read(new File("DNewman.jpg"));}
        catch(IOException e){e.printStackTrace();}
        
    }
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;
        g.drawImage(image, 0, 0, null);
        g2d.dispose();
    }
}
