package GameInfo;

public class MP2ProjectMain{
    public static void main(String[] args){
        JFrameLayout jFrameHandler = new JFrameLayout();
        jFrameHandler.layout();
    }
}
