package GameInfo;
import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class SoundPlayer {
    private File soundFile;
    private AudioInputStream audioInputStream;
    private Clip clip;
    public SoundPlayer(String fileName){
        soundFile = new File(fileName);
        try{audioInputStream = AudioSystem.getAudioInputStream(soundFile);}
        catch(IOException e){e.printStackTrace();}
        catch(UnsupportedAudioFileException e){e.printStackTrace();}
        try{clip = AudioSystem.getClip();}
        catch(LineUnavailableException e){e.printStackTrace();}
        try{clip.open(audioInputStream);}
        catch(LineUnavailableException e){e.printStackTrace();}
        catch(IOException e){e.printStackTrace();}
    }

    public void startAudio(){
        clip.start();
    }
    public void stopAudio(){
        clip.stop();
    }
    public void resetAudio(){
        clip.setMicrosecondPosition(0);
    }
    public void resetAudioandLoop(){
        clip.setMicrosecondPosition(0);
        startAudio();
        clip.loop(Clip.LOOP_CONTINUOUSLY);
    }
    public void setLoop(){
        clip.loop(Clip.LOOP_CONTINUOUSLY);
    }

}

